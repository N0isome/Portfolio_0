# Licencias de esta demo Windows

El código de JUCE PLUGGIN de esta entrega se distribuye bajo **GNU GPL v3**.
La licencia completa está en `LICENSE.txt`. Las fuentes correspondientes
se distribuyen junto al binario en la sección Software del portafolio,
incluidas las fuentes de JUCE 7.0.12 necesarias para compilar el plugin en `LoopCapture/vendor/JUCE`.

- **JUCE 7.0.12** — Copyright Raw Material Software Limited.
  Para esta entrega se usa su opción GPL v3. Se conserva `JUCE7-LICENSE.md`
  y la licencia original dentro del código de JUCE. Versión exacta:
  https://github.com/juce-framework/JUCE/tree/7.0.12
- **VST3 SDK** incluido en JUCE 7.0.12 — Copyright Steinberg Media Technologies GmbH.
  Para esta entrega se usa su opción GPL v3. Se conserva `VST3-SDK-LICENSE.txt`
  y los textos originales del SDK dentro de las fuentes.
- **Space Grotesk / IBM Plex Mono** — SIL Open Font License 1.1.
  Sus avisos completos están en `Assets/Fonts/*-OFL.txt`.
- **MinGW-w64 11 / GCC 13** — bibliotecas de ejecución enlazadas estáticamente.
  MinGW-w64 conserva las licencias de sus componentes; las bibliotecas GCC
  usan GPL v3 con GCC Runtime Library Exception. Los textos correspondientes
  se incluyen en `Runtime-Licenses/` del paquete binario.

El nombre JUCE PLUGGIN identifica esta demo de FR3DO. No implica respaldo
ni afiliación con JUCE, Steinberg o Image-Line.
